<?php

	include_once 'Roteador.class.php';

	class Controller {

		protected $data;

		function setData($name, $dt = null) {
			$this->data[$name] = $dt;
		}

		protected function view ($pag = NULL) {
			$r = new Roteador(); 
			$c = $r->getController();
			$a = $r->getAction();

			if(!is_null($this->data)){
			
				foreach($this->data as $name => $value){
					$$name = $value;
				}
			}


			if ($pag){
				return require_once('view/'.$c.'/'.$pag.'.phtml');
			}
			else{
				return require_once('view/'.$c.'/'.$a.'.phtml');
			}
			exit();
		}
	}
?>