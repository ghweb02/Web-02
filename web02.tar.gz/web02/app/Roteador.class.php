<?php

	class Roteador {

		var $uri;
		var $controller;
		var $action;
		var $param;

		function __construct() {
			$this->parametros();
		}

		function parametros() {
			$this->uri = (isset($_GET['key']) ? explode('/', $_GET['key']) : array('Index', 'index'));
			$this->controller();
			$this->action();
			$this->extrairParam();
		}

		function controller() {
			$this->controller = $this->uri[0];
		}

		function getController() {
			return $this->controller;
		}

		function action() {
			//$this->action = ($this->uri[1] && strlen($this->uri[1])) ? $this->uri[1]:'index';
			$this->action = (isset($this->uri[1]) && strlen($this->uri[1])) ? $this->uri[1]:'index';
		}

		function getAction() {
			return $this->action;
		}

		function extrairParam() {
			$this->uri = array_filter($this->uri);
			if(count($this->uri)>2) {
				for ($i=2;$i<count($this->uri);$i++){
					$this->param[] = $this->uri[$i];
				}
				 
			}
			else {
				$this->param = NULL;
			}

		}

		function getParam() {
			return $this->param;
		}
	}

?>