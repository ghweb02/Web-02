<?php

	class Arquivo {

		private $diretorio;

		function __construct($dir) {
			$this->diretorio = $dir;
		}

		function getDados() {
			try {
				$dados = file($this->diretorio);
				return $dados;
			}
			catch (Expection $e) {
				echo $e->getMessage();
			}
		}
	}
?>