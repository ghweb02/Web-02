<?php

	include_once 'Arquivo.class.php';
	
	$nomes = new Arquivo('nomes');

	$dados = $nomes->getDados();
	
	foreach ($dados as $d) {
		echo $d.'<br>';
	}

?>	