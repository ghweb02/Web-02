    <?php

    require 'models/ProfessorModel.class.php';
    include_once 'app/Controller.class.php';

    class ProfessorController extends Controller {
        function getEmail() {
            $p = new ProfessorModel();
            $email = $p->getEmail();
            $this->view();
        }

        function getSenha() {
        	$p = new ProfessorModel();
        	$senha = $p->getSenha();
        	$this->view();
        }

        function listar($p = NULL) {
            $pm = new ProfessorModel();
            $data = $pm->getDados($p);
            //passar para a view
            parent::setData("professores", $data); //$this->setData($data);
            $this->view();
        }

        function cadastrar() {
            $this->view();
        }

        function cadastrarEfetivo() {
            $pm = new ProfessorModel();
            $pm->setData($_POST);
            $res = $pm->cadastrar();
            ($res)?$this->view('sucesso'):$this->view('falha'); 
        }

        function delete($id) {
            $pm = new ProfessorModel();
            
            if($pm->deletar($id[0])) {
                $this->view('sucesso');
                return true;
            } 

            else {
                $this->view('falha');
                return false;
            }
            
        }  

        function index() {
            $this->view();
        }

        function __call($method, $arg) {
            $this->view('call');
        }
    }
?>    