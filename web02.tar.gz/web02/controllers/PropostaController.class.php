<?php

    require 'models/PropostaModel.class.php';
    include_once 'app/Controller.class.php';

    class PropostaController extends Controller {

    	function getNomeEmpresa() {
    		$p = new PropostaModel();
            $nomeEmpresa = $p->getNomeEmpresa();
            $this->view();
    	}

    	function getCargoOfertado() {
    	 	$p = new PropostaModel();
            $cargoOfertado = $p->getCargoOfertado();
            $this->view();
    	}

    	function getSalarioOferecido() {
   		 	$p = new PropostaModel();
            $salarioOferecido = $p->getSalarioOferecido();
            $this->view(); 		
    	}

    	function getDataEntrevista() {
    	    $p = new PropostaModel();
            $dataEntrevista = $p->getDataEntrevista();
            $this->view();	
    	}

    	function index() {
        	//echo 'Metodo padrao Index';
            $this->view();
        }

        function __call($method, $arg) {
            $this->view('call');
        }
    }
?>    