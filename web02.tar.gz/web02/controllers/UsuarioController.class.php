<?php

    require 'models/UsuarioModel.class.php';
    include_once 'app/Controller.class.php';

    class UsuarioController extends Controller {

        function getNome() {
            $d = new UsuarioModel();
            $nome = $d->getNome();
            $this->view();
        }

        function getIdade() {
            $d = new UsuarioModel();
            $nome = $d->getIdade();
            $this->view();
        }

        function getTelefone() {
            $d = new UsuarioModel();
            $nome = $d->getTelefone();
            $this->view();
        }

         function getCpf() {
            $d = new UsuarioModel();
            $nome = $d->getCpf();
            $this->view();
        }

        function getGraduacao() {
            $d = new UsuarioModel();
            $nome = $d->getGraduacao();
            $this->view();
        }

        function index() {
        	//echo 'Metodo padrao Index';
            $this->view();
        }

        function __call($method, $arg) {
            $this->view('call');
        }
    }
?>