<?php

    require 'models/ExperienciaModel.class.php';
    include_once 'app/Controller.class.php';

    class ExperienciaController extends Controller {

    	function getEmpresa() {
            $ex = new ExperienciaModel();
            $empresa = $ex->getEmpresa();
            $this->view();
        }

        function getSalario() {
            $ex = new ExperienciaModel();
            $salario = $ex->getSalario();
            $this->view();
        }

        function getCargo() {
            $ex = new ExperienciaModel();
            $cargo = $ex->getCargo();
            $this->view();
        }

        function getDda() {
            $ex = new ExperienciaModel();
            $dataDeAdmissao = $ex->getDda();
            $this->view();
        } 

        function getDde() {
            $ex = new ExperienciaModel();
            $dataDeDemissao = $ex->getDde();
            $this->view();
        }    

        function index() {
            $this->view();
        }

        function __call($method, $arg) {
            $this->view('call');
        }
    }
?>    