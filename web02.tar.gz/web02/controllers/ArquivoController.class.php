<?php

	require 'models/ArquivoModel.class.php';
    include_once 'app/Controller.class.php';

    class ArquivoController extends Controller {

    	function verDados() {
    		$a = new ArquivoModel('../projeto/nomes');
    		$dados = $a->getDados();
    		$this->setData($dados);
    		$this->view();
    	}

        function index() {
            $this->view();
        }

        function __call($method, $arg) {
            $this->view('call');
        }
    }
?>