<?php
	
	include_once 'app/Controller.class.php';

	class IndexController extends Controller {

		function index() {
			$this->view();
		}

		function __call($method, $arg) {
            $this->view('call');
        }
	}
?>