<?php

	include_once 'helpers/Arquivo.class.php';

	class ArquivoModel {

		private $dataBase;

		function __construct($db) {
			$this->dataBase = $db;
		}

		function getDados() {
			$a = new Arquivo($this->dataBase);
			return $a->getLinhas();
		}
	}
?>