<?php

	class PropostaModel {

		private $nomeEmpresa;
		private $cargoOfertado;
		private $salarioOferecido;
		private $dataEntrevista;

		function setNomeEmpresa($n) {
			$this->nomeEmpresa = $n;
		}
		function getNomeEmpresa() {
			return $this->nomeEmpresa;
		}

		function setCargoOfertado($c) {
			$this->nomeCargoOfertado = $c;
		}
		function getCargoOfertado() {
			return $this->cargoOfertado;
		}

		function setSalarioOferecido($s) {
			$this->salarioOferecido = $s;
		}
		function getSalarioOferecido() {
			return $this->salarioOferecido;
		}

		function setDataEntrevista($dt) {
			$this->dataEntrevista = $dt;
		}
		function getDataEntrevista() {
			return $this->dataEntrevista;
		}
	}
?>