<?php

	class UsuarioModel {

		private $nome;
		private $idade;
		private $telefone;
		private $cpf;
		private $graduacao;

		function setNome($n){
			$this->nome = $n;
		}
		function getNome(){
			return $this->nome;
		}
		
		function setIdade($i){
			$this->idade = $i;
		}
		function getIdade(){
			return $this->idade;
		}

		function setTelefone($t){
			$this->telefone = $t;
		}
		function getTelefone(){
			return $this->telefone;
		}

		function setCpf($cp){
			$this->cpf = $cp;
		}
		function getCpf(){
			return $this->cpf;
		}

		function setGraduacao($grad){
			$this->graduacao = $grad;
		}
		function getGraduacao(){
			return $this->graduacao;
		}
	}
?>