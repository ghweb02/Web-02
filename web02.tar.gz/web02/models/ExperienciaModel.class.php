<?php

	class ExperienciaModel {

		private $empresa;
		private $salario;
		private $cargo;
		private $dataDeAdmissao;
		private $datadeDemissao;

		function setEmpresa($e) {
			$this->empresa = $e;
		}
		function getEmpresa() {
			return $this->empresa;
		}

		function setSalario($s) {
			$this->salario = $s;
		}
		function getSalario() {
			return $this->salario;
		}

		function setCargp($c) {
			$this->cargo = $c;
		}
		function getCargo() {
			return $this->cargo;
		}

		function setDda($dda) {
			$this->dataDeAdmissao = $dda;
		}
		function getDda() {
			return $this->dataDeAdmissao;
		}

		function setDde($dde) {
			$this->datadeDemissao = $dde;
		}
		function getDde() {
			return $this->datadeDemissao;
		}
	}
?>