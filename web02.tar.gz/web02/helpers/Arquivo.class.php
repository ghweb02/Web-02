<?php

	class Arquivo {

		private $diretorio;

		function __construct($dir) {
			$this->diretorio = $dir;
		}

		function getLinhas() {
			try {
				$dados = file($this->diretorio);
				return $dados;
			}
			catch (Expection $e) {
				echo $e->getMessage();
			}
		}
	}
?>