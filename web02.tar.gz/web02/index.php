
<?php
    require_once 'app/Roteador.class.php';    

    function __autoload($class) {
        include_once "controllers/".$class.".class.php";
    }

    $r = new Roteador();
    
    $c = $r->getController().'Controller';
    $a = $r->getAction();
    
    $p = $r->getParam();
    //var_dump($p);
    $obj = new $c;

    if (is_null($p))
    	$obj->$a();
   	else  
   		$obj->$a($p);
?>